SELECT IIF(GROUPING_ID(k.kategoria) > 0, 'Összeg', k.kategoria), COUNT(*) AS SikeresVizsgakSzama
FROM VIZSGA v JOIN KURZUS k ON v.kurzus_id = k.kurzus_id
WHERE v.pontszam >= 80
GROUP BY ROLLUP(k.kategoria)
ORDER BY COUNT(*) ASC;