Csoporttagok: 

Badics Balázs (EF5U80)
Sziva Dániel (TSGCHU)