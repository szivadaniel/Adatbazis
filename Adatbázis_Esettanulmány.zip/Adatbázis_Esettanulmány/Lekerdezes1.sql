SELECT o.nev AS OktatoNev, COUNT(DISTINCT k.kategoria) AS Darabszám
FROM OKTATO o JOIN KURZUS k ON o.oktato_id = k.oktato_id
GROUP BY o.nev
