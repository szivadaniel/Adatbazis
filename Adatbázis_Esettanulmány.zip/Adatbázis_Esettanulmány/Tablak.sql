CREATE TABLE OKTATO(
 
  oktato_id INT IDENTITY(1,1) PRIMARY KEY,
  nev varchar(30),
  szul_datum DATE,
  email varchar(50)
);

CREATE TABLE DIAK(
 
  diak_id INT IDENTITY(1,1) PRIMARY KEY,
  nev nvarchar(30),
  szul_datum DATE,
  email varchar(50)
);


CREATE TABLE KURZUS(
  
  kurzus_id INT IDENTITY(1,1) PRIMARY KEY,
  oktato_id INT,
  diak_id INT,
  FOREIGN KEY (oktato_id) REFERENCES OKTATO(oktato_id),
  FOREIGN KEY (diak_id) REFERENCES DIAK(diak_id),
  kategoria varchar(5)
  
);

CREATE TABLE TANORA(
 
  tanora_id INT IDENTITY(1,1) PRIMARY KEY,
  idotartam INT,
  kurzus_id INT,
  FOREIGN KEY (kurzus_id) REFERENCES KURZUS(kurzus_id)
  
);

CREATE TABLE VIZSGAZTATO(
 
  Vizsgaztato_id INT IDENTITY(1,1) PRIMARY KEY,
  Nev NVARCHAR(30),
  Szul_datum DATE
);


CREATE TABLE VIZSGA(
 
  vizsga_id INT IDENTITY(1,1) PRIMARY KEY,
  datum DATE,
  pontszam INT,
  kurzus_id INT,
  vizsgaztato_id INT,
  FOREIGN KEY(kurzus_id) REFERENCES KURZUS(kurzus_id),
  FOREIGN KEY(vizsgaztato_id) REFERENCES VIZSGAZTATO(vizsgaztato_id)
  
);

