SELECT o.nev,
CASE
    WHEN SUM(t.idotartam) < 100 THEN 'Kezdő'
    WHEN SUM(t.idotartam) >= 100 AND SUM(t.idotartam) < 200 THEN 'Haladó'
    ELSE 'Tapasztalt'
END as tapasztalati_szint
FROM OKTATO o
JOIN KURZUS k on k.oktato_id = o.oktato_id
JOIN TANORA t ON t.kurzus_id = k.kurzus_id
GROUP BY o.nev
ORDER BY SUM(t.idotartam) DESC
