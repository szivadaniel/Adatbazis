SELECT 
  o.nev, COUNT(DISTINCT k.kategoria) AS Darabszam,
  CASE
    WHEN COUNT(DISTINCT k.kategoria) = 2 THEN '20%'
    WHEN COUNT(DISTINCT k.kategoria) > 2 THEN '25%'
    ELSE '0%'
  END AS Bonusz
FROM OKTATO o JOIN KURZUS k ON o.oktato_id = k.oktato_id
GROUP BY o.nev
